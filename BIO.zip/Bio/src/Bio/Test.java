package Bio;

public class Test {

	public static void main(String[] args) {
		
		Arbol arbol1 = new Arbol();
		Flor flor1 = new Flor();
		Arbusto arbusto1 = new Arbusto();
		
		arbol1.decirLoQueSoy();
		flor1.decirLoQueSoy();
		arbusto1.decirLoQueSoy();

	}

}
